WASasquatch was one of the original prompt libraries, dating back to Disco Diffusion - those were the days! You can import them using a script in the _tools directory. From the root directory of the extension, simply run to download it:

	python _tools/import_noodle_soup_prompts.py

Script contributed by @akx
