A large wildcards library kindly contributed by [@devilkkw](https://github.com/devilkkw).

Find their other work below:

#### HuggingFace
###### [KKW FANTAREAL V1.0](https://huggingface.co/devilkkw/KKW_FANTAREAL_V1.0 "kkw models")

#### Civitai
###### [KKW FANTAREAL V1.0](https://civitai.com/models/3782/kkw-fantareal-v10 "kkw models")

![KKW FATAREAL V1.0 SAMPLE IMAGE](https://s3.amazonaws.com/moonup/production/uploads/1672798387706-63076d1ecd148dbc5e4ccf57.jpeg "KKW FANTAREAL V1.0")
